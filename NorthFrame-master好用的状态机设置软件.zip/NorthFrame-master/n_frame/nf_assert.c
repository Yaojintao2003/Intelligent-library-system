#include "nf_assert.h"

void NF_Assert_Failed(const char* file, NF_Int32U line)
{
    while (1);
}
